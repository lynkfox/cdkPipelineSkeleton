if __name__ == '__main__':
    from keyring import cli

    cli.main()
